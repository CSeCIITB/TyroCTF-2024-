import string, re
from flask import Flask, request, render_template
import requests, html

app = Flask(__name__)

ipv4_pattern = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'
blacklistedIPs = ['127.0.0.1', '::1', '127.1', '0.0.0.0']

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/add/address", methods=["POST"])
def add_address():
    address = request.form.get("address")
    if not address:
        return render_template("index.html", message="No address provided")
    ip = address.split("//")[-1].split(":")[0]
    if not re.match(ipv4_pattern, ip):
        return render_template("index.html", message="Only urls like http(s)://<ip>/<path> are allowed. No hostnames allowed!")
    elif ip in blacklistedIPs:
        return render_template("index.html", message="Blacklisted ip spotted!")

    response = requests.get(address, verify=False)
    if(response.status_code != 200):
        return render_template("index.html", message="Only 200 response codes are allowed!")
    return render_template("index.html", message=html.escape(response.text))


@app.route("/api/flag", methods=["GET"])
def getFlag():
    remote_address = request.remote_addr
    if remote_address != "127.0.0.1" and remote_address != "::1":
        return render_template("index.html", message="Only localhost allowed")

    return open("/flag.txt","rt").read()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=1337, debug=False)
