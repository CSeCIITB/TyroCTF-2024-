// JavaScript for the cookie functionality
document.getElementById('clickMe').addEventListener('click', function() {
    const cookie = document.cookie;
    const cookieMessage = cookie.split(';').find(cookie => cookie.includes('Secret-Message'));
    
    if (cookieMessage) {
        alert(cookieMessage.trim());
    } else {
        alert('Secret-Message cookie not found.');
    }
});

document.getElementById('showIframe').addEventListener('click', function() {
    fetch('./php/load_file.php?file=anothersecretmsg.html')
        .then(response => response.text())
        .then(content => {
            const iframeContainer = document.getElementById('iframeContainer');
            iframeContainer.innerHTML = content;
        });
});



// Set a default cookie
document.cookie = "Secret-Message=Welcome to CSeC's tyroCTF";

// Hidden Flag Part 1 HERE