<?php
$file = $_GET['file'];

header("Location: http://localhost/sources/$file")
?>
