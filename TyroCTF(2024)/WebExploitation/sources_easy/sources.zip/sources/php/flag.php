<?php
// Allow access when included as a GET parameter
echo 'Hidden Flag Part 3 HERE';
?>