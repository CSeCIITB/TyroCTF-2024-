CREATE TABLE users (
    user VARCHAR(50),
    password VARCHAR(50)
);
INSERT INTO users (user, password) VALUES ('admin', 'd0gsaremybestfr13nds');