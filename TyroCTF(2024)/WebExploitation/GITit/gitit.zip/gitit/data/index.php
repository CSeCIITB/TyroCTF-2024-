<?php
session_start();

// Set your SQLite database path
$database = new SQLite3('/opt/data/webapp.db');

// Function to create the users table if it doesn't exist
function createUsersTable($database) {
    $createTableQuery = "CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL
    )";

    return $database->exec($createTableQuery);
}

// Initialize the database and create the users table
createUsersTable($database);

// Function to authenticate the user
function authenticate($database, $username, $password) {
    $query = "SELECT password FROM users WHERE username = :username";
    $stmt = $database->prepare($query);
    $stmt->bindValue(':username', $username, SQLITE3_TEXT);
    $result = $stmt->execute();
    $row = $result->fetchArray(SQLITE3_ASSOC);

    if ($row) {
        $storedPassword = $row['password'];
        $inputPasswordHash = hash('sha256', $password);

        if ($inputPasswordHash == $storedPassword) {
            return true;
        }
    }

    return false;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (authenticate($database, $username, $password)) {
        $_SESSION['username'] = $username;
        $_SESSION['success'] = 'Login successful!';
        header('Location: home.php');
        exit();
    } else {
        $error = 'Invalid username or password. Please try again.';
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <?php if (isset($error)) : ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <label for="username">Username</label>
        <input type="text" name="username" required><br>
        <label for="password">Password</label>
        <input type="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
