#!/bin/bash

sqlite3 /opt/data/webapp.db < /opt/data/db-data.sql
service apache2 start